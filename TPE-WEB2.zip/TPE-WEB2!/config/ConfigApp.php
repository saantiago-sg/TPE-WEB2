<?php
$port = ":80";
define ('Logout', "Location: http://".$_SERVER["SERVER_NAME"] . dirname($_SERVER["PHP_SELF"]). '/logout');
define('Home', "Location: http://".$_SERVER["SERVER_NAME"] . dirname($_SERVER["PHP_SELF"]));
define ('Login', "Location: http://".$_SERVER["SERVER_NAME"] . dirname($_SERVER["PHP_SELF"]). '/login');
class ConfigApp

{
    public static $ACTION = 'action';
    public static $PARAMS = 'params';
    public static $ACTIONS = [
        '' => 'noticias_controller#home',
        'agregar' => 'noticias_controller#agregarNoticia',
        'agregarClub' => 'noticias_controller#agregarClub',
        'borrar' => 'noticias_controller#borrarNoticia',
        'cambiar' => 'noticias_controller#cambiar',
        'editar' => 'noticias_controller#mostrarEditNoticia',
        'borrar-club' => 'noticias_controller#borrarClub',
        'cambiarClub' => 'noticias_controller#cambiarClub',
        'editar-club' => 'noticias_controller#mostrarEditClub',
        'filtrar' => 'noticias_controller#filtrarNoticia',
        'login' => 'login_controller#login',
        'verificar' => 'login_controller#verificar',
        'registro' => 'login_controller#mostrarRegistro',
	    'registrarse' => 'login_controller#registrarCuenta',
	    'logout' => 'login_controller#logout',
        
    ];

}