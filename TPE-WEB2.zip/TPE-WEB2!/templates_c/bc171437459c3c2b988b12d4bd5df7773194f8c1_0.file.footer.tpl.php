<?php
/* Smarty version 3.1.33, created on 2019-10-29 22:09:14
  from 'C:\xampp\htdocs\TPE-WEB2\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5db8aa7a551c88_14946081',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bc171437459c3c2b988b12d4bd5df7773194f8c1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\TPE-WEB2\\templates\\footer.tpl',
      1 => 1572383333,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db8aa7a551c88_14946081 (Smarty_Internal_Template $_smarty_tpl) {
?> <footer class="page-footer font-small pt-1 fondo-footer text-center">

        <div class="container">
            <div class="row mt-2">
                <div class="col">
                    <a href="#"><img src="img/icoFacebook.png" alt="" class="img-fluid"></a>
                </div>
                <div class="col">
                    <a href="#"><img src="img/icoInstagram.png" alt="" class="img-fluid"></a>
                </div>
                <div class="col">
                    <a href="#"><img src="img/icoTwitter.png" alt="" class="img-fluid"></a>
                </div>
                <div class="col">
                    <a href="#"><img src="img/icoYoutube.png" alt="" class="img-fluid"></a>
                </div>
            </div>
        </div>
    </footer><?php }
}
