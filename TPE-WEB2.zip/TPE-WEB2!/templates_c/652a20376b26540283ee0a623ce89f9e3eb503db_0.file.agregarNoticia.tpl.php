<?php
/* Smarty version 3.1.33, created on 2019-10-29 22:41:55
  from 'C:\xampp\htdocs\TPE-WEB2\templates\agregarNoticia.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5db8b223df4727_75065676',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '652a20376b26540283ee0a623ce89f9e3eb503db' => 
    array (
      0 => 'C:\\xampp\\htdocs\\TPE-WEB2\\templates\\agregarNoticia.tpl',
      1 => 1572385158,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db8b223df4727_75065676 (Smarty_Internal_Template $_smarty_tpl) {
?>
  <section class="fondo-ultimas-noticias pr-3 pl-3 pb-3 pt-0 pt-3">
<div class="abm">
<form action="<?php echo $_smarty_tpl->tpl_vars['ruta']->value;?>
/agregar" method="post">
<h5 class="h5-responsive font-weight-bold text-center titulo-fondo py-2 w-100 text-white">Agregar una noticia</h5>
  <div class="form-group small">
  <label for="exampleFormControlFile1" class="mt-3" >Titulo de la noticia</label>
  <input class="form-control" type="text" name="titulo">
  <label for="exampleFormControlFile1" class="mt-3" >Descripcion de la noticia</label>
  <input class="form-control" type="text" name="descripcion">
  <label for="exampleFormControlFile1" class="mt-3" >Fecha de publicacion</label>
  <input class="form-control" type="date" name="fecha">
  <select id="inputState" class="form-control mt-3" name="club">
        <option selected>Elige Un Club</option>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['clubes']->value, 'club');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['club']->value) {
?>
          <option><?php echo $_smarty_tpl->tpl_vars['club']->value['nombre_club'];?>
</option>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        
      </select>
  <label for="exampleFormControlFile1" class="mt-3" >Nombre de la imagen</label>
  <input class="form-control" type="text" name="imagen">
  </div>
  <button type="submit" class="btn mb-2 btnCrear text-white">Crear una nueva noticia</button>
</form>

</div>

</section>

<section class="fondo-ultimas-noticias pr-3 pl-3 pb-3 pt-0 pt-3 mt-2">
<form action="<?php echo $_smarty_tpl->tpl_vars['ruta']->value;?>
/agregarClub" method="post">
  <div class="form-group small">
  <label for="exampleFormControlFile1" class="mt-3" >Ingrese un nuevo club</label>
  <input class="form-control mb-3" type="text" name="club">
  <button type="submit" class="btn mb-2 btnCrear text-white">Crear un nuevo club</button>
</form>

</div>

</section>





<?php }
}
