<?php
require_once "./view/noticias_view.php";
require_once "./model/noticias_model.php";
require_once "./model/club_model.php";
require_once "secured_controller.php";
class noticias_controller extends secured_controller
{
    private $view;
    private $model;
    
    function __construct()
    {
        parent::__construct();
        $this->view = new noticias_view();
        $this->model = new noticias_model();
        $this->model_club = new club_model();

    }

    function home(){
        $noticia=$this->model->obtenerNoticias();
        $club=$this->model_club->obtenerClub();
        $ruta='.';
        $this->view->home($noticia,$club,$ruta,$this->isAdmin);   
    }


function agregarNoticia(){
    if ($this->isAdmin==true) {
    $titulo=$_POST['titulo'];
    $descripcion=$_POST['descripcion'];
    $fecha=$_POST['fecha'];
    $club=$_POST['club'];
    $imagen=$_POST['imagen'];
    $this->model->agregarNoticia($titulo,$descripcion,$fecha,$club,$imagen);
    header(Home);
    }
    header(Home);
}

function borrarNoticia($id_club){
    if ($this->isAdmin==true) {
        $this->model->borrarNoticia($id_club[0]);
        header(Home);
    }
    header(Home);
}

function cambiar(){
    $id=$_POST['noticia'];
    $titulo=$_POST['titulo'];
    $descripcion=$_POST['descripcion'];
    $fecha=$_POST['fecha'];
    $club=$_POST['club'];
    $imagen=$_POST['imagen'];
    $this->model->cambiar($id,$titulo,$descripcion,$fecha,$club,$imagen);
    var_dump($id);
    header(Home);
}
function mostrarEditNoticia($id){
    if ($this->isAdmin==true) {
        $club=$this->model_club->obtenerClub();
        $this->view->mostrarEditNoticia($id[0],$club);
    }
   
}

function agregarClub(){
    if ($this->isAdmin==true) {
    $club=$_POST['club'];
    $this->model_club->agregarClub($club);
    header(Home);
    }
    header(Home);
}

function filtrarNoticia($id){
    $noticia=$this->model->filtrarNoticia($id[0]);
    $club=$this->model_club->obtenerClub();
    $ruta='..';
    $this->view->home($noticia,$club,$ruta,$this->isAdmin); 
}

function borrarClub($id_club){
if ($this->isAdmin==true) {
    $this->model_club->borrarClub($id_club[0]);
    header(Home);
}
header(Home);
}

function mostrarEditClub($id_club){
    if ($this->isAdmin==true) {
        $this->view->mostrarEditClub($id_club[0]);
        }
}

function cambiarClub(){
    $id=$_POST['id_club'];
    $club=$_POST['club'];
    $this->model_club->cambiarClub($id,$club);
    header(Home);
}

}


