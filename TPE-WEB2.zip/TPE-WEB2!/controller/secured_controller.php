<?php
class secured_controller
{
    protected $isAdmin=false;
    function __construct()
    {
        session_start();
        if (isset($_SESSION["usuario"])){
            return $this->isAdmin= true;
        }else{       
        return $this->isAdmin=false;
    }
    }   
}
