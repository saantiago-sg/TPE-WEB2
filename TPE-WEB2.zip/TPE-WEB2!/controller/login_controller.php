<?php
require_once "./view/login_view.php";
require_once "./model/login_model.php";
class login_controller
{
    private $view;
    private $model;

    function __construct()
    {   
        
        $this->view=new login_view;
        $this->model=new login_model;
    }

    function login(){
        $this->view->mostrarLogin("");
    }

    function verificar(){
        $usuario=$_POST['usuario'];
        $contraseña=$_POST['contraseña'];
        $dbUsuario = $this->model->obtenerUsuario($usuario);
        if(isset($dbUsuario)&&($dbUsuario!=null)){
            if(password_verify($contraseña, $dbUsuario[0]["contraseña"])){ //el 0 va por la posicion del arreglo
                session_start();
                $_SESSION["usuario"] = $usuario;
                header(Home);
            }
            else{
                $this->view->mostrarLogin('Contraseña Incorrecta');
            }
        }else{
            $this->view->mostrarLogin('Usuario Incorrecto');
        }
    }

    function mostrarRegistro(){
        $this->view->mostrarRegistro();
    }

    function registrarCuenta(){
        $usuario=$_POST['usuario'];
        $contraseña=$_POST['contraseña'];
        $hash = password_hash($contraseña, PASSWORD_DEFAULT);
        $this->model->registrarCuenta($usuario,$hash);
        $this->view->mostrarLogin('Usted Se Ha Registrado Correctamente');
        header(Home);
    }

    function logout(){
        session_start();
        session_destroy();
        header(Home);
    }
    
    }



